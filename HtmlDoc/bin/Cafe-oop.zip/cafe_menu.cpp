#include "cafe_menu.h"
#include <algorithm>

Cafe_Menu::Cafe_Menu(void)
{
	printf_s("Cafe_Menu was created...\n");
}


Cafe_Menu::~Cafe_Menu(void)
{
	printf_s("Cafe_Menu was deleted...\n");

}
