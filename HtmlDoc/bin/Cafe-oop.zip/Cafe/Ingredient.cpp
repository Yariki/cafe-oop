///////////////////////////////////////////////////////////
//  Ingredient.cpp
//  Implementation of the Class Ingredient
//  Created on:      16-Nov-2013 8:48:15 PM
///////////////////////////////////////////////////////////

#include "Ingredient.h"


Ingredient::Ingredient(int type)
{
	
}



Ingredient::~Ingredient(){
	
}
