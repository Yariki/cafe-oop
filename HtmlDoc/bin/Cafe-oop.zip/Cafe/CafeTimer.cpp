#include "CafeTimer.h"


CafeTimer::CafeTimer(void)
{
	
}


CafeTimer::~CafeTimer(void)
{
}
