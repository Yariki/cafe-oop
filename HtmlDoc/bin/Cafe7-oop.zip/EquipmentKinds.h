///////////////////////////////////////////////////////////
//  EquipmentKinds.h
//  Implementation of the Class EquipmentKinds
//  Created on:      16-Nov-2013 8:48:14 PM
///////////////////////////////////////////////////////////

#if !defined(EA_42B7D36D_3297_4b31_BDAE_32109BD14096__INCLUDED_)
#define EA_42B7D36D_3297_4b31_BDAE_32109BD14096__INCLUDED_

enum EquipmentKinds
{
	ElectricRange,
	GasRange,
	FirePlace
};
#endif // !defined(EA_42B7D36D_3297_4b31_BDAE_32109BD14096__INCLUDED_)
