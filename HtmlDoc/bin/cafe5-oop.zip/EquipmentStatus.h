///////////////////////////////////////////////////////////
//  EquipmentStatus.h
//  Implementation of the Class EquipmentStatus
//  Created on:      16-Nov-2013 8:48:14 PM
///////////////////////////////////////////////////////////

#if !defined(EA_4045941E_5688_4445_8E54_5A7252DAA93E__INCLUDED_)
#define EA_4045941E_5688_4445_8E54_5A7252DAA93E__INCLUDED_

enum EquipmentStatus
{
	EquipmentFree,
	EquipmentBusy,
	EquipmentBroken,
	EquipmentInException
};
#endif // !defined(EA_4045941E_5688_4445_8E54_5A7252DAA93E__INCLUDED_)
