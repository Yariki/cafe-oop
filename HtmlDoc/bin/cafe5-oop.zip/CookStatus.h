///////////////////////////////////////////////////////////
//  CookStatus.h
//  Implementation of the Class CookStatus
//  Created on:      16-Nov-2013 8:48:10 PM
///////////////////////////////////////////////////////////

#if !defined(EA_8EAA39A2_33DE_42f3_BC0F_4C9E1A9DEA89__INCLUDED_)
#define EA_8EAA39A2_33DE_42f3_BC0F_4C9E1A9DEA89__INCLUDED_

enum CookStatus
{
	CookBusy,
	CookFree,
	CookReady,
	CookSneck
};
#endif // !defined(EA_8EAA39A2_33DE_42f3_BC0F_4C9E1A9DEA89__INCLUDED_)
