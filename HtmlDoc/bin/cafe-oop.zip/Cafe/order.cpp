#include "order.h"
#include <algorithm>

Order::Order(void)
{
	
}

Order::~Order(void)
{
	
}
