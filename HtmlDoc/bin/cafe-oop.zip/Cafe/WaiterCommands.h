///////////////////////////////////////////////////////////
//  WaiterCommands.h
//  Implementation of the Class WaiterCommands
//  Created on:      23-Nov-2013 10:13:34 PM
///////////////////////////////////////////////////////////

#if !defined(EA_B0A3C626_B936_46ba_A37E_05695F8928E6__INCLUDED_)
#define EA_B0A3C626_B936_46ba_A37E_05695F8928E6__INCLUDED_

enum WaiterCommands
{
	ApproveIgredients,
	PassOrderToChef,
	GetOrderFromClient,
	PassDishToClient,
	ProcessBill
};
#endif // !defined(EA_B0A3C626_B936_46ba_A37E_05695F8928E6__INCLUDED_)
