///////////////////////////////////////////////////////////
//  FirewoodException.cpp
//  Implementation of the Class FirewoodException
//  Created on:      20-Nov-2013 11:18:15 PM
///////////////////////////////////////////////////////////

#include "FirewoodException.h"


FirewoodException::~FirewoodException(){
}