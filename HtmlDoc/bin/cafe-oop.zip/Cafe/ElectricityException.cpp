///////////////////////////////////////////////////////////
//  ElectricityException.cpp
//  Implementation of the Class ElectricityException
//  Created on:      20-Nov-2013 11:18:13 PM
///////////////////////////////////////////////////////////

#include "ElectricityException.h"



ElectricityException::~ElectricityException(){
	
}