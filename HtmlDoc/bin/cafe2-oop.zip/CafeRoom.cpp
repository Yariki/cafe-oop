///////////////////////////////////////////////////////////
//  CafeRoom.cpp
//  Implementation of the Class CafeRoom
//  Created on:      16-Nov-2013 8:48:03 PM

///////////////////////////////////////////////////////////

#include "CafeRoom.h"


CafeRoom::~CafeRoom(){

}

CafeRoom::CafeRoom(){
	
}
