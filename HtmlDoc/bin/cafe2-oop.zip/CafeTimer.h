
#ifndef _CAFETIMER_H_
#define _CAFETIMER_H_

#include <ctime>

class CafeTimer
{
public:
	CafeTimer(void);
	virtual ~CafeTimer(void);

};

#endif //_CAFETIMER_H_

