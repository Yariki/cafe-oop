///////////////////////////////////////////////////////////
//  CafeStoreHouse.cpp
//  Implementation of the Class CafeStoreHouse
//  Created on:      16-Nov-2013 8:48:04 PM
///////////////////////////////////////////////////////////

#include "CafeStoreHouse.h"
#include <algorithm>

#define  MAX_COUNT_INGRIDIENT 1000

CafeStoreHouse::CafeStoreHouse(){
	printf_s("CafeStoreHouse was created...\n");
}

CafeStoreHouse::~CafeStoreHouse(){
	printf_s("CafeStoreHouse was deleted...\n");
}

