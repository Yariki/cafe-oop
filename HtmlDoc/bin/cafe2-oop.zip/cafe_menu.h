
#ifndef _CAFE_MENU_H_
#define _CAFE_MENU_H_

#include "dish.h"
#include <vector>

class Cafe_Menu
{
public:
	Cafe_Menu(void);        
    virtual ~Cafe_Menu(void);
};

#endif