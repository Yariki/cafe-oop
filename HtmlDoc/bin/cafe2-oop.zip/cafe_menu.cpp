#include "cafe_menu.h"
#include <algorithm>

Cafe_Menu::Cafe_Menu(void)
{
}


Cafe_Menu::~Cafe_Menu(void)
{
}
