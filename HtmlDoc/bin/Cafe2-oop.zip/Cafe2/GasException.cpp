///////////////////////////////////////////////////////////
//  GasException.cpp
//  Implementation of the Class GasException
//  Created on:      20-Nov-2013 11:18:14 PM
///////////////////////////////////////////////////////////

#include "GasException.h"



GasException::~GasException(){
	printf_s("GasException was deleted...\n");
}