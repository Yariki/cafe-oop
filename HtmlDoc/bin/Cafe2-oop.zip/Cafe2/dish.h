
#ifndef _DISH_H_
#define _DISH_H_

#include <string>
#include <map>
#include <string>
#include "Ingredient.h"

class Dish 
{
public:
	Dish(void);
	Dish(const Dish&);
    virtual ~Dish(void);

};

#endif