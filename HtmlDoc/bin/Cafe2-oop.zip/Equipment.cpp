///////////////////////////////////////////////////////////
//  Equipment.cpp
//  Implementation of the Class Equipment
//  Created on:      16-Nov-2013 8:48:13 PM

///////////////////////////////////////////////////////////

#include "Equipment.h"


Equipment::~Equipment(){
	printf_s("Equipment was deleted...\n");
}

Equipment::Equipment(){
	printf_s("Equipment was created...\n");
}

Equipment::Equipment( const Equipment& inst)
{
	printf_s("Equipment was created (copy ctor)...\n");
}
