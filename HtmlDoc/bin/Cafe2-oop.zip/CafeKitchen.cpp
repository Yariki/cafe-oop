///////////////////////////////////////////////////////////
//  CafeKitchen.cpp
//  Implementation of the Class CafeKitchen
//  Created on:      16-Nov-2013 8:48:02 PM

///////////////////////////////////////////////////////////

#include "CafeKitchen.h"
#include <algorithm>

#include "ElectricityException.h"
#include "GasException.h"
#include "FirewoodException.h"

#include <iostream>

using std::cout;
using std::cin;

CafeKitchen::CafeKitchen(){
	printf_s("CafeKitchen was created...\n");
}

CafeKitchen::~CafeKitchen(){
	printf_s("CafeKitchen was deleted...\n");
}
