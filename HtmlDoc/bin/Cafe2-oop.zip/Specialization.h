///////////////////////////////////////////////////////////
//  Specialization.h
//  Implementation of the Class Specialization
//  Created on:      16-Nov-2013 8:48:18 PM
///////////////////////////////////////////////////////////

#if !defined(EA_952DEF3F_349C_432f_952A_AF688BFC5285__INCLUDED_)
#define EA_952DEF3F_349C_432f_952A_AF688BFC5285__INCLUDED_

enum Specialization
{
	S_Cook,
	S_Chef,
	S_Client,
	S_Waiter
};
#endif // !defined(EA_952DEF3F_349C_432f_952A_AF688BFC5285__INCLUDED_)
