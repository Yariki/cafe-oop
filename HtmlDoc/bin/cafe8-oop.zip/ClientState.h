///////////////////////////////////////////////////////////
//  ClientState.h
//  Implementation of the Class ClientState
//  Created on:      22-Nov-2013 1:06:40 AM
//  Original author: Yariki
///////////////////////////////////////////////////////////

#if !defined(EA_B468F2A0_3CDC_4db9_A3EF_37F0A9B82414__INCLUDED_)
#define EA_B468F2A0_3CDC_4db9_A3EF_37F0A9B82414__INCLUDED_

enum ClientState
{
	New,
	NotServe,
	Serve
};
#endif // !defined(EA_B468F2A0_3CDC_4db9_A3EF_37F0A9B82414__INCLUDED_)
