///////////////////////////////////////////////////////////
//  IngredientKinds.h
//  Implementation of the Class IngredientKinds
//  Created on:      16-Nov-2013 8:48:16 PM
///////////////////////////////////////////////////////////

#if !defined(EA_627326EE_A8AB_46b1_96BB_208F41C7E940__INCLUDED_)
#define EA_627326EE_A8AB_46b1_96BB_208F41C7E940__INCLUDED_

enum IngredientKinds
{
	Meat,
	Salt,
	Peper,
	Rice,
	Flour,
	Chicken,
	Fish,
	Sauce,
	Tomato,
	Potatoes
};
#endif // !defined(EA_627326EE_A8AB_46b1_96BB_208F41C7E940__INCLUDED_)
