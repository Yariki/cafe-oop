///////////////////////////////////////////////////////////
//  EnergyKinds.h
//  Implementation of the Class EnergyKinds
//  Created on:      16-Nov-2013 8:48:12 PM
///////////////////////////////////////////////////////////

#if !defined(EA_693F8587_7DC4_497c_8FBE_3AFE585AC3F1__INCLUDED_)
#define EA_693F8587_7DC4_497c_8FBE_3AFE585AC3F1__INCLUDED_

enum EnergyKinds
{
	Electricity,
	Gas,
	Firewood
};
#endif // !defined(EA_693F8587_7DC4_497c_8FBE_3AFE585AC3F1__INCLUDED_)
