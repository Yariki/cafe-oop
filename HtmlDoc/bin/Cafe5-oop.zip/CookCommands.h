///////////////////////////////////////////////////////////
//  CookCommands.h
//  Implementation of the Class CookCommands
//  Created on:      22-Nov-2013 1:32:38 AM
///////////////////////////////////////////////////////////

#if !defined(EA_335D96FF_9186_42f5_A900_B5F7CDAE46E6__INCLUDED_)
#define EA_335D96FF_9186_42f5_A900_B5F7CDAE46E6__INCLUDED_

enum CookCommands
{
	CheckIngridients,
	PassDishToWaiter,
	CookInjured,
	ApplyEquipment,
	ReleaseEquipment,
	SetOrderToCook,
	PassSneckToWaiter,
	FinishedWork
};
#endif // !defined(EA_335D96FF_9186_42f5_A900_B5F7CDAE46E6__INCLUDED_)
